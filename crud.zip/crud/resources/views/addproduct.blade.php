<link rel="stylesheet" type="text/css" href={{ URL::asset('css/bootstrap.min.css') }}>
<div class="container">

@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif

 @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
 <div class="row">
   <div class="col-sm-4 col-md-4">
     <div class="row">
    <form method="post" action=""  enctype="multipart/form-data">
         @csrf
    <input type="hidden" name="id" @if(isset($getproduct[0]['id'])) value="{{ $getproduct[0]['id'] }}" @else value="" @endif >
    <legend>Add Products</legend>    
    <div class="form-group">
      <label for="name">Name</label>
      <input type="text" class="form-control" placeholder="Enter name" name="pname" @if(isset($getproduct[0]['pname'])) value="{{ $getproduct[0]['pname'] }}" @else value="{{ old('pname')}}" @endif  >
     <span class="text-danger">{{ $errors->first('pname') }}</span>
  </div>
  <div class="form-group">
      <label for="name">Price</label>
      <input type="text" class="form-control" placeholder="Enter price" name="price" @if(isset($getproduct[0]['price'])) value="{{ $getproduct[0]['price'] }}" @else value="{{ old('price')}}" @endif >
       <span class="text-danger">{{ $errors->first('price') }}</span>
  </div> 
  <div class="form-group">
      <label for="name">Quantity</label>
      <input type="text" class="form-control" placeholder="Enter quantity" name="qty"  @if(isset($getproduct[0]['qty'])) value="{{ $getproduct[0]['qty'] }}" @else value="{{ old('qty')}}" @endif >
      <span class="text-danger">{{ $errors->first('qty') }}</span>
  </div> 
  <div class="form-group">
      <label for="name">Image</label>
      <br>
       @if(isset($getproduct[0]['image'])) 
          <img src="{{ url('images/'.$getproduct[0]['image']) }}" width="80" height="80">
       @endif 
      <input type="file" class="form-control" name="image">

       <span class="text-danger">{{ $errors->first('image') }}</span>
  </div>  
  <button type="submit" class="btn btn-success">Submit</button>
  
</form>
    
  </div>
   </div>
   <div class="col-sm-8 col-md-8">
    <div class="text-right" style="padding: 20px">
      <a href="{{ url('testuser') }}" class="btn btn-primary"> add New Product </a>
    </div>
     <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">S.no</th>
      <th scope="col">Image</th>
      <th scope="col">Name</th>
      <th scope="col">price</th>
      <th scope="col">Qty</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    @if(!empty($allproduct))
      @foreach($allproduct as $key => $product)
        <?php 
$sno=0;
        if(isset($_GET['page'])){
            $sno = $_GET['page'];
        }elseif($sno > 1){
           $sno = $_GET['page'] ;
        }else{
          $sno =0;
        } ?>
          <tr class="table">


            <th scope="row">{{ ( $sno+$key+1)}}</th>
            <th><img src="{{ url('images/'.$product->image)}}" width="80" height="80"></th>
            <td>{{$product->pname}}</td>
            <td>{{$product->price}}</td>
            <td>{{$product->qty}}</td>
            <td><a href="{{URL::to('/editProduct/'.$product->id) }}" class="btn btn-info">Edit</a> <a href="{{URL::to('/deleteProduct/'.$product->id) }}" class="btn btn-danger">Delete</a> </td>
          </tr>
      @endforeach
    @endif
   
  </tbody>
</table> 
{{ $allproduct->render() }}
   </div>
 </div>

  
</div>
