<?php 

echo "Hello Navi";
echo "this is my test mail";
echo "This time lavkush sent you mai ";
?>
