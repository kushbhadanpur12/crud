<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use Mail;


class Sentmail extends Controller
{
	public function index(){

			Mail::send(['text'=>'emails.mymailpage'],['name'=>'Lavkush'],function($message){
    		$message->to('navi.sagar05@gmail.com','Mail Test')->subject('To check Mail');
    		$message->from('lavkush.maihar01@gmail.com','Test');

    	});
	}
  
}
