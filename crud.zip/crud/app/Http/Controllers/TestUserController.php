<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use Illuminate\Pagination\LengthAwarePaginator;

class TestUserController extends Controller
{
    public function index()
    {
    	$data = array();
    	$data['allproduct'] = Product::paginate(2);
    	return view('addproduct',$data);
    }
    public function insertProduct(Request $request)
    {
    	
    	$validatedata = $request->validate([
	        'pname' => 'required|max:255',
	        'price' => 'required|integer',
	        'qty' 	=> 'required|integer',
	        'image' => 'required|mimes:jpeg,bmp,png'
   		 ]);

    		$image = $request->file('image');
			$imgname = time().$image->getClientOriginalName() ;
			$destinationPath = public_path('/images');
			$image->move($destinationPath, $imgname);

    		$obj = new Product;
    		$obj->pname = $request->pname;
    		$obj->price = $request->price;
    		$obj->qty 	= $request->qty;
    		$obj->image = $imgname;
    		if($obj->save())
    			return redirect()->back()->with('message', 'product insert successfully');
    }
    public function deleteProduct($id)
    {

    	$product = Product::find($id)->delete();
    	if($product)
    	  return redirect()->back()->with('message', 'product deleted successfully');
       
    }
   public function editProduct($id)
    {

    	$data['getproduct']  = Product::where('id',$id)->get();
    	$data['allproduct'] = Product::all();
    	return view('addproduct',$data);
       
    }

  public function updateProduct(Request $request)
    {
    	$id = $request->id;
    	$validatedata = $request->validate([
	        'pname' => 'required|max:255',
	        'price' => 'required|integer',
	        'qty' 	=> 'required|integer'
   		 ]);

    		if($request->file('image')){
	    		$image = $request->file('image');
				$imgname = time().$image->getClientOriginalName();
				$destinationPath = public_path('/images');
				$image->move($destinationPath, $imgname);
    		}
    		

    		if($request->file('image')){
    			$datavalue=array(
		              'pname'=>$request->pname,
		              'price'=>$request->price,
		              'qty'=>$request->qty,
		              'image'=>$imgname
            	); 
    		}else{
    			$datavalue=array(
		              'pname'=>$request->pname,
		              'price'=>$request->price,
		              'qty'=>$request->qty,
		             ); 

    		}
           
		Product::where('id',$id)->update($datavalue);
		$data['getproduct '] = '';
		$data['allproduct'] = Product::all(); 
		return redirect()->back()->with('message', 'Product updated successfully');
       
    }
}
