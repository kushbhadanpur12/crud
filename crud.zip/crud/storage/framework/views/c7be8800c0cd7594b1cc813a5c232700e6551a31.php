<link rel="stylesheet" type="text/css" href=<?php echo e(URL::asset('css/bootstrap.min.css')); ?>>
<div class="container">

<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>

 <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
 <div class="row">
   <div class="col-sm-4 col-md-4">
     <div class="row">
    <form method="post" action=""  enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
    <input type="hidden" name="id" <?php if(isset($getproduct[0]['id'])): ?> value="<?php echo e($getproduct[0]['id']); ?>" <?php else: ?> value="" <?php endif; ?> >
    <legend>Add Products</legend>    
    <div class="form-group">
      <label for="name">Name</label>
      <input type="text" class="form-control" placeholder="Enter name" name="pname" <?php if(isset($getproduct[0]['pname'])): ?> value="<?php echo e($getproduct[0]['pname']); ?>" <?php else: ?> value="<?php echo e(old('pname')); ?>" <?php endif; ?>  >
     <span class="text-danger"><?php echo e($errors->first('pname')); ?></span>
  </div>
  <div class="form-group">
      <label for="name">Price</label>
      <input type="text" class="form-control" placeholder="Enter price" name="price" <?php if(isset($getproduct[0]['price'])): ?> value="<?php echo e($getproduct[0]['price']); ?>" <?php else: ?> value="<?php echo e(old('price')); ?>" <?php endif; ?> >
       <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
  </div> 
  <div class="form-group">
      <label for="name">Quantity</label>
      <input type="text" class="form-control" placeholder="Enter quantity" name="qty"  <?php if(isset($getproduct[0]['qty'])): ?> value="<?php echo e($getproduct[0]['qty']); ?>" <?php else: ?> value="<?php echo e(old('qty')); ?>" <?php endif; ?> >
      <span class="text-danger"><?php echo e($errors->first('qty')); ?></span>
  </div> 
  <div class="form-group">
      <label for="name">Image</label>
      <br>
       <?php if(isset($getproduct[0]['image'])): ?> 
          <img src="<?php echo e(url('images/'.$getproduct[0]['image'])); ?>" width="80" height="80">
       <?php endif; ?> 
      <input type="file" class="form-control" name="image">

       <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
  </div>  
  <button type="submit" class="btn btn-success">Submit</button>
  
</form>
    
  </div>
   </div>
   <div class="col-sm-8 col-md-8">
    <div class="text-right" style="padding: 20px">
      <a href="<?php echo e(url('testuser')); ?>" class="btn btn-primary"> add New Product </a>
    </div>
     <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">S.no</th>
      <th scope="col">Image</th>
      <th scope="col">Name</th>
      <th scope="col">price</th>
      <th scope="col">Qty</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php if(!empty($allproduct)): ?>
      <?php $__currentLoopData = $allproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
$sno=0;
        if(isset($_GET['page'])){
            $sno = $_GET['page'];
        }elseif($sno > 1){
           $sno = $_GET['page'] ;
        }else{
          $sno =0;
        } ?>
          <tr class="table">


            <th scope="row"><?php echo e(( $sno+$key+1)); ?></th>
            <th><img src="<?php echo e(url('images/'.$product->image)); ?>" width="80" height="80"></th>
            <td><?php echo e($product->pname); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td><?php echo e($product->qty); ?></td>
            <td><a href="<?php echo e(URL::to('/editProduct/'.$product->id)); ?>" class="btn btn-info">Edit</a> <a href="<?php echo e(URL::to('/deleteProduct/'.$product->id)); ?>" class="btn btn-danger">Delete</a> </td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
   
  </tbody>
</table> 
<?php echo e($allproduct->render()); ?>

   </div>
 </div>

  
</div>
